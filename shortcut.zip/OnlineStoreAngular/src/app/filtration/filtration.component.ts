import { Component } from '@angular/core';
import { HttpService } from '../shared/http.service';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-filtration',
  templateUrl: './filtration.component.html',
  styleUrl: './filtration.component.css'
})
export class FiltrationComponent {
  public storeData:any

  constructor(private httpService:HttpService,private cartService :CartService){
    this.httpService.getAllstores().subscribe(data => console.log(data))

    this.httpService.getAllstores().subscribe(data => {
      this.storeData = data
    })
  }
addtocart(item : any){
  this.cartService.addtoCart(item); 
}
}
