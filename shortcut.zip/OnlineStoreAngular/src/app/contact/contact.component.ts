import { HttpClient, HttpParams } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css'
})
export class ContactComponent {
 registerForm: FormGroup;
  isLoading = false;
  errorMessage = '';
  private apiUrl = 'http://your-api-url/api/User/register'; // Update with your actual API URL

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.registerForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  onSubmit() {
    if (this.registerForm.invalid) return;

    this.isLoading = true;
    this.errorMessage = '';

    const { email, password } = this.registerForm.value;
    const params = new HttpParams().set('email', email).set('password', password);

    this.http.post<boolean>(this.apiUrl, {}, { params }).subscribe({
      next: (response: any) => {
        console.log('User Registered:', response);
        this.isLoading = false;
        alert('Registration Successful!');
      },
      error: (error: any) => {
        console.error('Registration Failed:', error);
        this.errorMessage = 'Registration failed. Try again.';
        this.isLoading = false;
      },
    });
  }
}
