import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'FinalProjectBarkala';
  items: any[] = [];

  constructor(private dataService: DataService) {}

  ngOnInit() {
    this.dataService.getData().subscribe({
      next: (data: any[]) => {
        this.items = data;
        console.log('Success!', this.items);
      },
      error: (err) => {
        console.error('Connection Error: Check if C# is running and CORS is set.', err);
      }
    });
  }
}