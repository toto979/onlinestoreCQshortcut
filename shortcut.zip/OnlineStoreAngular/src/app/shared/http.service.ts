import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http:HttpClient) { }
  getSortedAsc(){
    return this.http.get('https://localhost:7288/api/Product/sorted?sortOrder=asc')
  }

  getAllstores(){
    return this.http.get('https://localhost:7288/api/Product/get-all-products')
  }


  getAllbycategory(category:string){
    return this.http.get(`https://localhost:7288/api/Product/filter/${category}`)
  }

  
}
