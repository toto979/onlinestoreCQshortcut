import { Component } from '@angular/core';
import { HttpService } from '../shared/http.service';
import { ActivatedRoute } from '@angular/router';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrl: './category.component.css'
})
export class CategoryComponent {

  public productId!:any
  public storeData: any  
  public productDatas!:any
  constructor(private httpService:HttpService,private cartService :CartService , private route:ActivatedRoute){

    this.route.params.subscribe(data1 => {
      this.productId = data1
      console.log(data1)
    })

    this.httpService.getAllbycategory(this.productId.params).subscribe(data => {
      this.productDatas = data
      console.log(this.productDatas)
    })
    {
      this.httpService.getAllstores().subscribe(data => console.log(data))
  
      this.httpService.getAllstores().subscribe(data => {
        this.storeData = data
      })
    }
  }
  addtocart(item : any){
    this.cartService.addtoCart(item); 
  }
}
