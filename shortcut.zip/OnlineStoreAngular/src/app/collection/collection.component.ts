import { Component } from '@angular/core';
import { HttpService } from '../shared/http.service';



@Component({
  selector: 'app-collection',
  templateUrl: './collection.component.html',
  styleUrl: './collection.component.css'
})
export class CollectionComponent {

  public storeData:any

  constructor(private httpService:HttpService){
    this.httpService.getAllstores().subscribe(data => console.log(data))

    this.httpService.getAllstores().subscribe(data => {
      this.storeData = data
    })
  }
}

