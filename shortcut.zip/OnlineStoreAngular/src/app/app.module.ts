import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, provideHttpClient } from '@angular/common/http'; 
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component'; 
import { HomeComponent } from './home/home.component';
import { NavComponent } from './nav/nav.component';
import { CategoryComponent } from './category/category.component';
import { FiltrationComponent } from './filtration/filtration.component';
import { CollectionComponent } from './collection/collection.component';
import { ContactComponent } from './contact/contact.component';
import { FooterComponent } from './footer/footer.component';
import { SortByPriceComponent } from './sort-by-price/sort-by-price.component';
import { RegisterComponent } from './register/register.component';
import { BuyProductComponent } from './buy-product/buy-product.component';

@NgModule({
  declarations: [
    AppComponent, 
    HomeComponent,
    NavComponent,
    CategoryComponent,
    FiltrationComponent,
    CollectionComponent,
    ContactComponent,
    FooterComponent,
    SortByPriceComponent,
    RegisterComponent,
    BuyProductComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule, 
    ReactiveFormsModule
    
  ],
  providers: [
    provideHttpClient() 
  ],
  bootstrap: [AppComponent] 
})
export class AppModule { }