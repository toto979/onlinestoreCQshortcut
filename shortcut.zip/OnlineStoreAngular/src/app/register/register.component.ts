import { HttpClient, HttpParams } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  public product :any = [];
  public grandTotal !: number ;
  http: any;
  snackBar: any;
  
  constructor(private cartService : CartService){}
  ngOnInit():void{
    this.cartService.getProducts()
    .subscribe(res=>{
      this.product = res;
      this.grandTotal=this.cartService.getTotalPrice();
    })

   }
   removeItem(item:any){
    this.cartService.removeCartItem(item);

   }
   emptycart(){
    this.cartService.removeAllCart();
   }
   
   purchaseSuccess = false;

   buyProduct() {
    this.purchaseSuccess = true;
    setTimeout(() => {
      this.purchaseSuccess = false;
    }, 9000);
  }
}
