import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CollectionComponent } from './collection/collection.component'; 
import { ContactComponent } from './contact/contact.component';
import { FiltrationComponent } from './filtration/filtration.component';
import { CategoryComponent } from './category/category.component';
import { SortByPriceComponent } from './sort-by-price/sort-by-price.component';
import { RegisterComponent } from './register/register.component';
import { BuyProductComponent } from './buy-product/buy-product.component';

const routes: Routes = [
  {path:'homepage',component:HomeComponent},
  {path:'collection',component:CollectionComponent},
  {path:'contact',component:ContactComponent},
  {path:'filtration',component:FiltrationComponent},
  {path:'category/:params',component:CategoryComponent},
  {path:'sort-by-price',component:SortByPriceComponent},
  {path:'Cart',component:RegisterComponent},
  {path:'buy-product',component:BuyProductComponent}
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
