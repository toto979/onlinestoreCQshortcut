import { Component } from '@angular/core';
import { HttpService } from '../shared/http.service';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-sort-by-price',
  templateUrl: './sort-by-price.component.html',
  styleUrl: './sort-by-price.component.css'
})
export class SortByPriceComponent {

   public productData:any
  
    constructor(private httpService:HttpService,private cartService :CartService){
      this.httpService.getSortedAsc().subscribe(data1 => console.log(data1))
  
      this.httpService.getSortedAsc().subscribe(data1 => {
        this.productData = data1
      })
    }
    addtocart(item : any){
      this.cartService.addtoCart(item); 
    }
}
